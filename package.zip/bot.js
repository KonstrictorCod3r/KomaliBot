const Discord = require('discord.js');
const client = new Discord.Client();
const auth = require('./auth.json');
var blue = 693081014066741379;
var red = 693080851134545922;
var orange = 693080914057494600;
var yellow = 693080946840174632;
var green = 693080983330619443;
var purple = 693081044433240085;
require('events').EventEmitter.defaultMaxListeners = 15;

const PREFIX = "!";
client.on('message', function(message) {
	if(message.content[0] === PREFIX) {
		let splitMessage = message.content.split(" ");
		if(splitMessage[0] === '!color') {
			if(splitMessage.length === 2) {
                                                 if(message.member.roles.find("name", "Racer")){
                                                              const guildMember = message.member;
  				    if(splitMessage[1] === 'red'){
				guildMember.addRole('693080851134545922');
				message.reply('Color Applied!');
				    }
				if(splitMessage[1] === 'orange'){
				guildMember.addRole('693080914057494600');
				message.reply('Color Applied!');
				    }
				if(splitMessage[1] === 'yellow'){
				guildMember.addRole('693080946840174632');
				message.reply('Color Applied!');
				    }
				if(splitMessage[1] === 'green'){
				guildMember.addRole('693080983330619443');
				message.reply('Color Applied!');
				    }
				if(splitMessage[1] === 'lightblue'){
				guildMember.addRole('693081014066741379');
				message.reply('Color Applied!');
				    }
				if(splitMessage[1] === 'purple'){
				guildMember.addRole('693081044433240085');
				message.reply('Color Applied!');
				    }
				if(splitMessage[1] === 'darkblue'){
				guildMember.addRole('693098575651143730');
				message.reply('Color Applied!');
				}
				if(splitMessage[1] === 'list'){
				message.channel.send('Available Colors: (do !color ___ to get)  \n > red \n > orange \n > yellow \n > green \n > lightblue  \n > darkblue  \n > purple  \n Remember to do !removecolor before changing colors!');
				}
				if(splitMessage[1] !== 'list' && splitMessage[1] !== 'darkblue' && splitMessage[1] !== 'red' &&  splitMessage[1] !== 'orange' && splitMessage[1] !== 'yellow' && splitMessage[1] !== 'green' && splitMessage[1] !== 'blue' && splitMessage[1] !== 'purple'){
				message.reply('not a valid color');
				}
}
			}
		}
	}
});




client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);	
	client.user.setActivity("silence b/c its not working :/", {type:"Listening"})
});

client.on('message', msg => {
  if (msg.content === '!hi') {
    msg.reply('Hello!');
  }
client.on('message', (receivedMessage) => {
    // Prevent bot from responding to its own messages
    if (receivedMessage.author == client.user) {
        return
    }
});
});

client.on('message', msg => {
  if (msg.content === '!yay') {
    msg.channel.send('<:POGGERS:691701513155772457><:POGGERS:691701513155772457><:POGGERS:691701513155772457><:POGGERS:691701513155772457><:POGGERS:691701513155772457><:POGGERS:691701513155772457><:POGGERS:691701513155772457><:POGGERS:691701513155772457>');
  }
client.on('message', (receivedMessage) => {
    // Prevent bot from responding to its own messages
    if (receivedMessage.author == client.user) {
        return
    }
});
});

client.on('message', msg => {
  if (msg.content === '!removecolor') {
 msg.member.removeRole('693080851134545922');
msg.member.removeRole('693080914057494600');
msg.member.removeRole('693080946840174632');
msg.member.removeRole('693080983330619443');
msg.member.removeRole('693081014066741379');
msg.member.removeRole('693098575651143730');
msg.member.removeRole('693081044433240085');
msg.reply('Colors Removed');
client.on('message', (receivedMessage) => {
    // Prevent bot from responding to its own messages
    if (receivedMessage.author == client.user) {
        return
    }
});
};
});



client.on('message', msg => {
if (msg.content === "!slots") {
var slotstr = "";
var r1 = Math.floor(Math.random()* 13);
var e1 = "<:hecome:691701997312671905>";
var e2 = "<:smert:692111071384961146>";
var e3 = "<:stella:692397952362348546>"
var e4 = "<:luna:692401472352157787>";
var e5 = "<:FeelsBadMan:691702228913881089>";
var e6 = "<:monkaS:691702362376634418>";
var e7 = "<:monkaSes:691702399596888064>";
var e8 = "<:noice:692015455967379456>";
var e9 = "<:PogChamp:691704040534573127>";
var e10 = "<:idontunderstand:692139319619485736>";
var e11 = "<:kappa:691701838440824843>";
var e12 = "<:POGGERS:691701513155772457>";
var e13 = "<:KEKW:692111283000049824>";
var i = 0;
while(i != 3){
var r1 = Math.floor(Math.random()* 13);
if( r1 == 0){
slotstr = slotstr + e1;
}
if( r1 == 1){
slotstr = slotstr + e2;
}
if( r1 == 2){
slotstr = slotstr + e3;
}
if( r1 == 3){
slotstr = slotstr + e4;
}
if( r1 == 4){
slotstr = slotstr + e5;
}
if( r1 == 5){
slotstr = slotstr + e6;
}
if( r1 == 6){
slotstr = slotstr + e7;
}
if( r1 == 7){
slotstr = slotstr + e8;
}
if( r1 == 8){
slotstr = slotstr + e9;
}
if( r1 == 9){
slotstr = slotstr + e10;
}
if( r1 == 10){
slotstr = slotstr + e11;
}
if( r1 == 11){
slotstr = slotstr + e12;
}
if( r1 == 12){
slotstr = slotstr + e13;
}
i++;
};
msg.channel.send(slotstr);
msg.channel.send("Please play again!");
};
});

client.on('message', msg => {
if (msg.content === "!meow") {

var x = Math.floor(Math.random() * 2);

if(x == 0){
msg.channel.send('<:stella:692397952362348546>')
}
if(x == 1){
msg.channel.send('<:luna:692401472352157787>')
};
};
});




client.login(auth.token);